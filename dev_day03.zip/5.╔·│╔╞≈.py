from typing import Iterator

def f():
    print("Hello")
    yield 1  # 生成 1  类似return
    yield 2



g = (i for i in [1, 2])

# g = f()  # g是一个生成器对象
print(type(g))
print(hasattr(g, '__next__'))  # True
print(hasattr(g, '__iter__'))  # True
print(isinstance(g, Iterator))  # True
for i in g:
    print(i)


