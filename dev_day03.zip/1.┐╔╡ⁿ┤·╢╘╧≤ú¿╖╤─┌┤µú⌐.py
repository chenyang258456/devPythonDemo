from typing import Iterable


def range_test(stop):
    start = 0
    result = []
    while start < stop:
        result.append(start)
        start += 1
    return result


if __name__ == '__main__':
    print(isinstance(range_test(10), Iterable))
    print(range_test(999999999999))
