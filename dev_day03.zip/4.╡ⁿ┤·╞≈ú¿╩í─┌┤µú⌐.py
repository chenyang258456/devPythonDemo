from typing import Iterator, Iterable


class Next(object):
    def __init__(self, stop, start=-1):
        self.start = start
        self.stop = stop

    def __next__(self):
        if self.start >= self.stop - 1:
            raise StopIteration
        self.start += 1  # 用 累加1  生成 新的数据
        return self.start


class MyRange(object):
    def __init__(self, stop):
        self.stop = stop

    def __iter__(self):
        return Next(self.stop)  #  有__next__方法的对象


if __name__ == '__main__':
    for item in MyRange(10):
        print(item)
    # myrange = MyRange(10)
    # numbers = myrange.__iter__()
    # i = 0
    # while i < 10:
    #     print(numbers.__next__())
    #     i += 1
    print(1, isinstance(MyRange(10), Iterable))  # True  因为有 __iter__方法
    print(2, isinstance(Next(10), Iterable))  # False  没有__iter__方法
    print(3, hasattr(list, '__iter__'))
    print(4, hasattr(tuple, '__iter__'))
    print(5, hasattr(dict, '__iter__'))
    print(6, hasattr(1, '__iter__'))
    print(7, hasattr(list, '__next__'))  # False
    print(8, isinstance(Next(10), Iterator))  # False  因为虽然有__next__方法，但是缺少__iter__
    nums = Next(3)
    print(next(nums))
    print(next(nums))
    print(next(nums))
    print(next(nums))
