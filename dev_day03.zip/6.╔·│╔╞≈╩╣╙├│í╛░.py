#  使用场景： 边下载边保存

def download():
    data = {

    }
    yield data


def save():
    download()
