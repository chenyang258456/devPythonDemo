from typing import Iterator

class Ningmengban(Iterator):
    def __init__(self):
        self.students = [
            '花花',
            '马小赛',
            '小妖'
        ]
        self.index = 0

    def __next__(self):
        print("111")
        if self.index >= len(self.students):
            raise StopIteration
        self.index += 1
        return self.students[self.index - 1]


if __name__ == '__main__':
    nmb = Ningmengban()
    nmb.__next__()
    print(isinstance(nmb, Iterator))
    print(hasattr(nmb, '__iter__'))
    print(hasattr(nmb, '__next__'))
    for person in nmb:
        print(person)


